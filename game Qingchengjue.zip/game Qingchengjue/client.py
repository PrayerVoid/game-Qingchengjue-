import warnings
warnings.filterwarnings("ignore")
from PyQt6.QtWidgets import QWidget,QPushButton,QApplication,QLabel,QRadioButton,QButtonGroup
from PyQt6.QtGui import QIcon, QPixmap, QPainter,QFont
from PyQt6.QtCore import QTimer
from random import randint
from roles import role1,role2,role3
from cards import card1,card2,card3,card4,card5,card6,card7,card8,card9,card10,card11,card12,card13,card14,card15
import socket
from time import sleep

cardlist=[card1(),card2(),card3(),card4(),card5(),card6(),card7(),card8(),card9(),card10(),card11(),card12(),card13(),card14(),card15()]

def find(x):
    global cardlist
    for i in range(len(cardlist)):
        if cardlist[i].name==x.name:
            return i
        
def clientstart():
    addr = input('Please enter the id of the room:\n')
    #连接地址端口
    client=socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    client.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    client.connect((addr ,9999))
    print('You have entered the rome. The game starts now.')
    global myrole
    client.sendall(bytes(str(myrole),'utf-8'))
    return client

class iwin(QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("青城决")
        self.resize(1440, 850)
        self.setWindowIcon(QIcon('menu a.jpg'))
        tip=QLabel('青城决',self)
        tip.move(550,0)
        tip.resize(500,250)
        font0=QFont()
        font0.setPointSize(80)
        font0.setWeight(50)
        tip.setFont(font0)
        tip.show()
        self.button=QPushButton('你赢了！（单击以关闭）',self)
        self.button.move(520,375)
        self.button.resize(400,100)
        font = QFont()
        font.setPointSize(25)
        font.setWeight(50)
        self.button.setFont(font)
        self.button.show()
        self.button.clicked.connect(self.closeit)
    def closeit(self):
        QTimer.singleShot(1000,lambda :self.close())

    def paintEvent(self,event):
        painter = QPainter(self)
        pixmap = QPixmap("menu background.jpg")
        painter.drawPixmap(self.rect(), pixmap)


#敌方获胜界面
class itwin(QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("青城决")
        self.resize(1440, 850)
        self.setWindowIcon(QIcon('menu a.jpg'))
        tip=QLabel('青城决',self)
        tip.move(550,0)
        tip.resize(500,250)
        font0=QFont()
        font0.setPointSize(80)
        font0.setWeight(50)
        tip.setFont(font0)
        tip.show()
        self.button=QPushButton('你输了！（单击以关闭）',self)
        self.button.move(520,375)
        self.button.resize(400,100)
        font = QFont()
        font.setPointSize(25)
        font.setWeight(50)
        self.button.setFont(font)
        self.button.show()
        self.button.clicked.connect(self.closeit)
    def closeit(self):
        QTimer.singleShot(1000,lambda :self.close())

    def paintEvent(self,event):
        painter = QPainter(self)
        pixmap = QPixmap("menu background.jpg")
        painter.drawPixmap(self.rect(), pixmap)


class clientOnline(QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("青城决")
        self.resize(1440, 850)
        self.setWindowIcon(QIcon('menu a.jpg'))
        self.client=clientstart()
        global itsrole
        global myrole
        itsrole=int(self.client.recv(66666))

        #玩家信息展示
        self.myinformation=QLabel(self)
        if myrole==1:
            self.myinformation.setPixmap(QPixmap('role1.jpg')) 
        elif myrole==2:
            self.myinformation.setPixmap(QPixmap('role2.jpg'))
        elif myrole==3:
            self.myinformation.setPixmap(QPixmap('role3.jpg'))
        self.myinformation.move(0,0)
        self.myinformation.resize(200,200)
        self.myinformation.setStyleSheet('border: 2px solid black;')
        self.myinformation.setScaledContents(True)
        self.myinformation.show()

        if myrole==1:
            self.myinformation2=QLabel(role1().name+'(你)',self)
        elif myrole==2:
            self.myinformation2=QLabel(role2().name+'(你)',self)
        elif myrole==3:
            self.myinformation2=QLabel(role3().name+'(你)',self)
        self.myinformation2.move(200,0)
        self.myinformation2.resize(80,30)
        self.myinformation2.setStyleSheet('border: 2px solid black;background-color: white')
        self.myinformation2.setScaledContents(True)
        self.myinformation2.show()

        if myrole==1:
            self.myinformation3=QLabel('生命：'+str(role1().HP),self)
        elif myrole==2:
            self.myinformation3=QLabel('生命：'+str(role2().HP),self)
        elif myrole==3:
            self.myinformation3=QLabel('生命：'+str(role3().HP),self)
        self.myinformation3.move(200,30)
        self.myinformation3.resize(80,30)
        self.myinformation3.setStyleSheet('border: 2px solid red;background-color: white')
        self.myinformation3.setScaledContents(True)
        self.myinformation3.show()

        if myrole==1:
            self.myinformation4=QLabel('行动力：'+str(role1().MP),self)
        elif myrole==2:
            self.myinformation4=QLabel('行动力：'+str(role2().MP),self)
        elif myrole==3:
            self.myinformation4=QLabel('行动力：'+str(role3().MP),self)
        self.myinformation4.move(200,60)
        self.myinformation4.resize(80,30)
        self.myinformation4.setStyleSheet('border: 2px solid blue;background-color: white')
        self.myinformation4.setScaledContents(True)
        self.myinformation4.show()

        self.myinformation5=QLabel('护甲:0',self)
        self.myinformation5.move(200,90)
        self.myinformation5.resize(80,30)
        self.myinformation5.setStyleSheet('border: 2px solid green;background-color: white')
        self.myinformation5.setScaledContents(True)
        self.myinformation5.show()

        self.myinformation6=QLabel('牌堆:30',self)
        self.myinformation6.move(200,120)
        self.myinformation6.resize(80,30)
        self.myinformation6.setStyleSheet('border: 2px solid orange;background-color: white')
        self.myinformation6.setScaledContents(True)
        self.myinformation6.show()
        #敌方信息展示
        self.itsinformation=QLabel(self)
        if itsrole==1:
            self.itsinformation.setPixmap(QPixmap('role1.jpg')) 
        elif itsrole==2:
            self.itsinformation.setPixmap(QPixmap('role2.jpg'))
        elif itsrole==3:
            self.itsinformation.setPixmap(QPixmap('role3.jpg'))
        self.itsinformation.move(1240,650)
        self.itsinformation.resize(200,200)
        self.itsinformation.setStyleSheet('border: 2px solid black;')
        self.itsinformation.setScaledContents(True)
        self.itsinformation.show()

        if itsrole==1:
            self.itsinformation2=QLabel(role1().name+'(敌方)',self)
        elif itsrole==2:
            self.itsinformation2=QLabel(role2().name+'(敌方)',self)
        elif itsrole==3:
            self.itsinformation2=QLabel(role3().name+'(敌方)',self)
        self.itsinformation2.move(1160,650)
        self.itsinformation2.resize(80,30)
        self.itsinformation2.setStyleSheet('border: 2px solid black;background-color: white')
        self.itsinformation2.setScaledContents(True)
        self.itsinformation2.show()

        if itsrole==1:
            self.itsinformation3=QLabel('生命：'+str(role1().HP),self)
        elif itsrole==2:
            self.itsinformation3=QLabel('生命：'+str(role2().HP),self)
        elif itsrole==3:
            self.itsinformation3=QLabel('生命：'+str(role3().HP),self)
        self.itsinformation3.move(1160,680)
        self.itsinformation3.resize(80,30)
        self.itsinformation3.setStyleSheet('border: 2px solid red;background-color: white')
        self.itsinformation3.setScaledContents(True)
        self.itsinformation3.show()

        if itsrole==1:
            self.itsinformation4=QLabel('行动力：'+str(role1().MP),self)
        elif itsrole==2:
            self.itsinformation4=QLabel('行动力：'+str(role2().MP),self)
        elif itsrole==3:
            self.itsinformation4=QLabel('行动力：'+str(role3().MP),self)
        self.itsinformation4.move(1160,710)
        self.itsinformation4.resize(80,30)
        self.itsinformation4.setStyleSheet('border: 2px solid blue;background-color: white')
        self.itsinformation4.setScaledContents(True)
        self.itsinformation4.show()

        self.itsinformation5=QLabel('护甲:0',self)
        self.itsinformation5.move(1160,740)
        self.itsinformation5.resize(80,30)
        self.itsinformation5.setStyleSheet('border: 2px solid green;background-color: white')
        self.itsinformation5.setScaledContents(True)
        self.itsinformation5.show()

        self.itsinformation6=QLabel('牌堆:30',self)
        self.itsinformation6.move(1160,770)
        self.itsinformation6.resize(80,30)
        self.itsinformation6.setStyleSheet('border: 2px solid orange;background-color: white')
        self.itsinformation6.setScaledContents(True)
        self.itsinformation6.show()

        #接收服务器的初始化数据
        self.receive()

        #回合内设置
        global roundnow
        self.roundtip=QLabel('游戏开始',self)
        self.roundlist=['你的回合','敌方回合']
        self.roundtip.setText(self.roundlist[roundnow])
        self.roundtip.resize(200,100)
        self.roundtip.move(620,0)
        self.roundtipfont=QFont()
        self.roundtipfont.setPointSize(33)
        self.roundtipfont.setWeight(40)
        self.roundtip.setFont(self.roundtipfont)
        self.roundtip.setStyleSheet('border: 2px solid white;background-color: white')
        self.roundtip.show()
        self.roundend=QPushButton('结束回合',self)
        self.roundend.resize(200,100)
        self.roundend.move(620,400)
        self.roundend.setFont(self.roundtipfont)
        self.roundend.setStyleSheet('border: 2px solid black;background-color: white')
        self.roundend.clicked.connect(self.roundtransform)
        self.tip=QLabel('当前行动',self)
        self.tip.resize(200,200)
        self.tip.move(620,600)
        self.tip.setStyleSheet('border: 2px solid white;background-color: white')
        tipfont=QFont()
        tipfont.setPointSize(15)
        self.tip.setFont(tipfont)
        self.tip.setWordWrap(True)
        self.tip.show()
        #刷新一次
        self.mygroup=QButtonGroup(self)
        self.itsgroup=QButtonGroup(self)
        self.mydic={}
        self.itsdic={}
        self.refresh()
        if roundnow==1:
            QTimer.singleShot(500,self.itplay)

    def packdata(self):
        global roundnow
        global hp1
        global mp1
        global lp1
        global hp2
        global mp2
        global lp2
        global cardlist
        myhandcardsdata=''
        myleftcardsdata=''
        itshandcardsdata=''
        itsleftcardsdata=''
        for i in self.myhandcards:
            j=find(i)
            if myhandcardsdata=='':
                myhandcardsdata+=str(j)
            else:
                myhandcardsdata+='$'+str(j)
        for i in self.myleftcards:
            j=find(i)
            if myleftcardsdata=='':
                myleftcardsdata+=str(j)
            else:
                myleftcardsdata+='$'+str(j)
        for i in self.itshandcards:
            j=find(i)
            if itshandcardsdata=='':
                itshandcardsdata+=str(j)
            else:
                itshandcardsdata+='$'+str(j)
        for i in self.itsleftcards:
            j=find(i)
            if itsleftcardsdata=='':
                itsleftcardsdata+=str(j)
            else:
                itsleftcardsdata+='$'+str(j)
        data=str(roundnow)+'@'+str(hp1)+'@'+str(mp1)+'@'+str(lp1)+'@'+str(hp2)+'@'+str(mp2)+'@'+str(lp2)+'@'+myhandcardsdata+'@'+myleftcardsdata+'@'+itshandcardsdata+'@'+itsleftcardsdata
        return data
    
    def receive(self):
        global hp1
        global lp1
        global mp1
        global hp2
        global mp2
        global lp2
        global roundnow
        global cardlist
        try:
            data=str(self.client.recv(66666),'utf-8').split('@')
        except:
            return
        if data==['']:
            self.client.close()
            return
        roundnow=1-int(data[0])
        hp2=int(data[1])
        mp2=int(data[2])
        lp2=int(data[3])
        hp1=int(data[4])
        mp1=int(data[5])
        lp1=int(data[6])
        self.itshandcards=[]
        tsx=data[7].split('$')
        for i in tsx:
            if i:
                j=cardlist[int(i)]
                self.itshandcards.append(j)
        self.itsleftcards=[]
        tsx=data[8].split('$')
        for i in tsx:
            if i:
                j=cardlist[int(i)]
                self.itsleftcards.append(j)
        self.myhandcards=[]
        tsx=data[9].split('$')
        for i in tsx:
            if i:
                j=cardlist[int(i)]
                self.myhandcards.append(j)
        self.myleftcards=[]
        tsx=data[10].split('$')
        for i in tsx:
            if i:
                j=cardlist[int(i)]
                self.myleftcards.append(j)
        if len(data)==12:
            if itsrole==1:
                self.tip.setText(role1().name+'（敌方）打出了'+'《'+cardlist[int(data[11])].name+'》,效果为：'+cardlist[int(data[11])].able)
            elif itsrole==2:
                self.tip.setText(role2().name+'（敌方）打出了'+'《'+cardlist[int(data[11])].name+'》,效果为：'+cardlist[int(data[11])].able)
            elif itsrole==3:
                self.tip.setText(role3().name+'（敌方）打出了'+'《'+cardlist[int(data[11])].name+'》,效果为：'+cardlist[int(data[11])].able)

    def itplay(self):
            global hp1
            global mp1
            global lp1
            global hp2
            global mp2
            global lp2
            self.refresh()
            while roundnow==1:
                try:
                    self.client.settimeout(0.5)
                    QApplication.processEvents()
                    self.receive()
                except:
                    pass
                try:
                    self.client.settimeout(None)
                except:
                    return
                self.refresh()

    #每帧刷新
    def refresh(self):
        global hp1
        global lp1
        global mp1
        global hp2
        global mp2
        global lp2
        global roundnow
        for e in self.mygroup.buttons():
            e.close()
        for e in self.itsgroup.buttons():
            e.close()
        self.mygroup=QButtonGroup(self)
        self.itsgroup=QButtonGroup(self)
        self.myinformation3.setText('生命：'+str(hp1))
        self.myinformation4.setText('行动力：'+str(mp1))
        self.myinformation5.setText('护甲：'+str(lp1))
        self.myinformation6.setText('牌堆：'+str(len(self.myleftcards)))
        self.itsinformation3.setText('生命：'+str(hp2))
        self.itsinformation4.setText('行动力：'+str(mp2))
        self.itsinformation5.setText('护甲：'+str(lp2))
        self.itsinformation6.setText('牌堆：'+str(len(self.itsleftcards)))       
        if self.myhandcards:
            height1=650//len(self.myhandcards)
        btofont=QFont()
        for c in range(len(self.myhandcards)):
            bto=QRadioButton(self.myhandcards[c].name,self)
            self.mygroup.addButton(bto)
            self.mydic[bto]=self.myhandcards[c]
            bto.resize(200,height1)
            btofont.setPointSize(min(height1//4,30))
            bto.setFont(btofont)
            bto.move(0,c*height1+200)
            if self.myhandcards[c].mp==0:
                bto.setStyleSheet('border: 2px solid white;background-color: white')
            elif self.myhandcards[c].mp==1:
                bto.setStyleSheet('border: 2px solid pink;background-color: pink')
            elif self.myhandcards[c].mp==2:
                bto.setStyleSheet('border: 2px solid purple;background-color: purple')
            bto.clicked.connect(lambda :self.play(self.myhandcards,self.myleftcards,self.itshandcards,self.itsleftcards,self.mydic[self.mygroup.checkedButton()],hp1,mp1,lp1,hp2,mp2,lp2))
            bto.show()            
            
        if self.itshandcards:
            height2=650//len(self.itshandcards)
        btofont2=QFont()
        for c in range(len(self.itshandcards)):
            bto=QRadioButton(self.itshandcards[c].name,self)
            self.itsgroup.addButton(bto)
            self.itsdic[bto]=self.itshandcards[c]
            bto.resize(200,height2)
            btofont2.setPointSize(min(height2//4,30))
            bto.setFont(btofont)
            bto.move(1240,c*height2)
            if self.itshandcards[c].mp==0:
                bto.setStyleSheet('border: 2px solid white;background-color: white')
            elif self.itshandcards[c].mp==1:
                bto.setStyleSheet('border: 2px solid pink;background-color: pink')
            elif self.itshandcards[c].mp==2:
                bto.setStyleSheet('border: 2px solid purple;background-color: purple')
            bto.clicked.connect(lambda :self.play(self.itshandcards,self.itsleftcards,self.myhandcards,self.myleftcards,self.itsdic[self.itsgroup.checkedButton()],hp2,mp2,lp2,hp1,mp1,lp1))
            bto.show()           
            
        for bt in self.itsgroup.buttons():
            bt.setEnabled(False)
        if roundnow==1:
            for bt in self.mygroup.buttons():
                bt.setEnabled(False)
            self.roundend.setEnabled(False)
            self.roundtip.setText('敌方回合')
        elif roundnow==0:
            for bt in self.mygroup.buttons():
                bt.setEnabled(True)
            self.roundend.setEnabled(True)
            self.roundtip.setText('你的回合')
        self.checkwin()

    def roundtransform(self):
        global roundnow
        global mp1
        global lp1
        global mp2
        global lp2
        if roundnow==0:
            roundnow=1
            self.getcard(self.itsleftcards,self.itshandcards)
            self.getcard(self.itsleftcards,self.itshandcards)
            if itsrole==1:
                mp2=role1().MP
                lp2=0
            elif itsrole==2:
                mp2=role2().MP
                lp2=0
            elif itsrole==3:
                mp2=role3().MP
                lp2=0
            self.refresh()
            self.client.sendall(bytes(self.packdata(),'utf-8'))
            QTimer.singleShot(500,self.itplay)

    #出牌加上刷新
    def play(self,myhandcards,myleftcards,itshandcards,itsleftcards,card,HP1,MP1,LP1,HP2,MP2,LP2):
        global hp1
        global lp1
        global mp1
        global hp2
        global mp2
        global lp2
        global roundnow
        global myrole
        global itsrole
        endding=self.palycard(myhandcards,myleftcards,itshandcards,itsleftcards,card,HP1,MP1,LP1,HP2,MP2,LP2)
        if roundnow==0 and endding:
            hp1,mp1,lp1,hp2,mp2,lp2=endding
            if myrole==1:
                self.tip.setText(role1().name+'（你）打出了'+'《'+card.name+'》,效果为：'+card.able)
            elif myrole==2:
                self.tip.setText(role2().name+'（你）打出了'+'《'+card.name+'》,效果为：'+card.able)
            elif myrole==3:
                self.tip.setText(role3().name+'（你）打出了'+'《'+card.name+'》,效果为：'+card.able)
            self.client.sendall(bytes(self.packdata()+'@'+str(cardlist.index(card)),'utf-8'))
        self.refresh()
        return

    #出牌函数
    def palycard(self,myhandcards,myleftcards,itshandcards,itsleftcards,card,HP1,MP1,LP1,HP2,MP2,LP2):
        if card.mp>MP1:
            return ()
        return card.ability(myhandcards,myleftcards,itshandcards,itsleftcards,HP1,MP1,LP1,HP2,MP2,LP2)
    
    def getcard(self,leftcards,handcards):
        if not(leftcards):
            return
        handcards.append(leftcards.pop())
        return
    
    def checkwin(self):
        global hp1
        global hp2
        if hp1<=0 or not self.myleftcards:
            try:
                self.client.sendall(bytes(self.packdata(),'utf-8'))
            except:
                return
            QTimer.singleShot(500,lambda :self.client.close())
            self.close()
            self.ui=itwin()
            self.ui.show()
        elif hp2<=0 or not self.itsleftcards:
            try:
                self.client.sendall(bytes(self.packdata(),'utf-8'))
            except:
                return
            QTimer.singleShot(500,lambda :self.client.close())
            self.close()
            self.ui=iwin()
            self.ui.show()

    def paintEvent(self,event):
        painter = QPainter(self)
        pixmap = QPixmap("battle background.jpg")
        painter.drawPixmap(self.rect(), pixmap)

class clientfirstui(QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("青城决")
        self.resize(1440, 850)
        self.setWindowIcon(QIcon('menu a.jpg'))

        tip=QLabel('请选择你的侠客',self)
        tip.move(550,40)
        tip.resize(500,250)
        fonttip= QFont()
        fonttip.setPointSize(40)
        fonttip.setWeight(50)
        tip.setFont(fonttip)
        tip.show()

        self.role1tick=QPushButton(role1().name,self)
        self.role1tick.move(520,300)
        self.role1tick.resize(400,100)
        fontrole1= QFont()
        fontrole1.setPointSize(40)
        fontrole1.setWeight(50)
        self.role1tick.setFont(fontrole1)
        self.role1tick.show()
        self.role1tick.clicked.connect(self.role1)

        self.role2tick=QPushButton(role2().name,self)
        self.role2tick.move(520,500)
        self.role2tick.resize(400,100)
        fontrole2= QFont()
        fontrole2.setPointSize(40)
        fontrole2.setWeight(50)
        self.role2tick.setFont(fontrole2)
        self.role2tick.show()
        self.role2tick.clicked.connect(self.role2)

        self.role3tick=QPushButton(role3().name,self)
        self.role3tick.move(520,700)
        self.role3tick.resize(400,100)
        fontrole3= QFont()
        fontrole3.setPointSize(40)
        fontrole3.setWeight(50)
        self.role3tick.setFont(fontrole3)
        self.role3tick.show()
        self.role3tick.clicked.connect(self.role3)

    def role1(self):
        self.close()
        global myrole
        myrole=1
        self.ui1=clientOnline()
        self.ui1.show()

    def role2(self):
        self.close()
        global myrole
        myrole=2
        self.ui2=clientOnline()
        self.ui2.show()

    def role3(self):
        self.close()
        global myrole
        myrole=3
        self.ui3=clientOnline()
        self.ui3.show()

    def paintEvent(self,event):
        painter = QPainter(self)
        pixmap = QPixmap("battle background.jpg")
        painter.drawPixmap(self.rect(), pixmap)