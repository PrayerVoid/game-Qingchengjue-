from cards import card1,card2,card3,card4,card5,card6,card7,card8,card9,card10,card11,card12,card13,card14,card15,card16,card17,card18,card19,card20,card21,card22,card23,card24,card25,card26,card27,card28,card29,card30

class role1:
    def __init__(self):
        self.name='季千翎'
        self.cards=[card1(),card2(),card3(),card4(),card5()]
        self.HP=35
        self.MP=3

class role2:
    def __init__(self):
        self.name='岳沧海'
        self.cards=[card6(),card7(),card8(),card9(),card10()]
        self.HP=50
        self.MP=2

class role3:
    def __init__(self):
        self.name='战青云'
        self.cards=[card11(),card12(),card13(),card14(),card15()]
        self.HP=25
        self.MP=4

class role4:
    def __init__(self):
        self.name='雀儿'
        self.cards=[card16(),card17(),card18(),card19(),card20()]
        self.HP=40
        self.MP=5

class role5:
    def __init__(self):
        self.name='苏媚'
        self.cards=[card21(),card22(),card23(),card24(),card25()]
        self.HP=35
        self.MP=3

class role6:
    def __init__(self):
        self.name='令狐问道'
        self.cards=[card26(),card27(),card28(),card29(),card30()]
        self.HP=35
        self.MP=3

