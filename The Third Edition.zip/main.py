import warnings
warnings.filterwarnings("ignore")
from PyQt6.QtWidgets import QWidget,QPushButton,QApplication,QLabel,QRadioButton,QButtonGroup
from PyQt6.QtGui import QIcon, QPixmap, QPainter,QFont
from PyQt6.QtCore import QTimer
from random import randint
from roles import role1,role2,role3,role4,role5,role6
from sever import severfirstui
from client import clientfirstui
from time import sleep
#玩家获胜界面
class iwin(QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("青城决")
        self.resize(1440, 850)
        self.setWindowIcon(QIcon('menu a.jpg'))
        tip=QLabel('青城决',self)
        tip.move(550,0)
        tip.resize(500,250)
        font0=QFont()
        font0.setPointSize(80)
        font0.setWeight(50)
        tip.setFont(font0)
        tip.show()
        self.button=QPushButton('你赢了！（单击以关闭）',self)
        self.button.move(520,375)
        self.button.resize(400,100)
        font = QFont()
        font.setPointSize(25)
        font.setWeight(50)
        self.button.setFont(font)
        self.button.show()
        self.button.clicked.connect(self.closeit)
    def closeit(self):
        QTimer.singleShot(1000,lambda :self.close())

    def paintEvent(self,event):
        painter = QPainter(self)
        pixmap = QPixmap("menu background.jpg")
        painter.drawPixmap(self.rect(), pixmap)


#电脑获胜界面
class itwin(QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("青城决")
        self.resize(1440, 850)
        self.setWindowIcon(QIcon('menu a.jpg'))
        tip=QLabel('青城决',self)
        tip.move(550,0)
        tip.resize(500,250)
        font0=QFont()
        font0.setPointSize(80)
        font0.setWeight(50)
        tip.setFont(font0)
        tip.show()
        self.button=QPushButton('你输了！（单击以关闭）',self)
        self.button.move(520,375)
        self.button.resize(400,100)
        font = QFont()
        font.setPointSize(25)
        font.setWeight(50)
        self.button.setFont(font)
        self.button.show()
        self.button.clicked.connect(self.closeit)
    def closeit(self):
        QTimer.singleShot(1000,lambda :self.close())

    def paintEvent(self,event):
        painter = QPainter(self)
        pixmap = QPixmap("menu background.jpg")
        painter.drawPixmap(self.rect(), pixmap)



#人机对战界面
class playWithAI(QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("青城决")
        self.resize(1440, 850)
        self.setWindowIcon(QIcon('menu a.jpg'))
        #玩家信息展示
        self.myinformation=QLabel(self)
        global myrole
        if myrole==1:
            self.myinformation.setPixmap(QPixmap('role1.jpg')) 
        elif myrole==2:
            self.myinformation.setPixmap(QPixmap('role2.jpg'))
        elif myrole==3:
            self.myinformation.setPixmap(QPixmap('role3.jpg'))
        elif myrole==4:
            self.myinformation.setPixmap(QPixmap('role4.jpg'))
        elif myrole==5:
            self.myinformation.setPixmap(QPixmap('role5.jpg'))
        elif myrole==6:
            self.myinformation.setPixmap(QPixmap('role6.jpg'))
        self.myinformation.move(0,0)
        self.myinformation.resize(200,200)
        self.myinformation.setStyleSheet('border: 2px solid black;')
        self.myinformation.setScaledContents(True)
        self.myinformation.show()

        if myrole==1:
            self.myinformation2=QLabel(role1().name+'(你)',self)
        elif myrole==2:
            self.myinformation2=QLabel(role2().name+'(你)',self)
        elif myrole==3:
            self.myinformation2=QLabel(role3().name+'(你)',self)
        elif myrole==4:
            self.myinformation2=QLabel(role4().name+'(你)',self)
        elif myrole==5:
            self.myinformation2=QLabel(role5().name+'(你)',self)
        elif myrole==6:
            self.myinformation2=QLabel(role6().name+'(你)',self)
        self.myinformation2.move(200,0)
        self.myinformation2.resize(80,30)
        self.myinformation2.setStyleSheet('border: 2px solid black;background-color: white')
        self.myinformation2.setScaledContents(True)
        self.myinformation2.show()

        if myrole==1:
            self.myinformation3=QLabel('生命：'+str(role1().HP),self)
        elif myrole==2:
            self.myinformation3=QLabel('生命：'+str(role2().HP),self)
        elif myrole==3:
            self.myinformation3=QLabel('生命：'+str(role3().HP),self)
        elif myrole==4:
            self.myinformation3=QLabel('生命：'+str(role4().HP),self)
        elif myrole==5:
            self.myinformation3=QLabel('生命：'+str(role5().HP),self)
        elif myrole==6:
            self.myinformation3=QLabel('生命：'+str(role6().HP),self)
        self.myinformation3.move(200,30)
        self.myinformation3.resize(80,30)
        self.myinformation3.setStyleSheet('border: 2px solid red;background-color: white')
        self.myinformation3.setScaledContents(True)
        self.myinformation3.show()

        if myrole==1:
            self.myinformation4=QLabel('行动力：'+str(role1().MP),self)
        elif myrole==2:
            self.myinformation4=QLabel('行动力：'+str(role2().MP),self)
        elif myrole==3:
            self.myinformation4=QLabel('行动力：'+str(role3().MP),self)
        elif myrole==4:
            self.myinformation4=QLabel('行动力：'+str(role4().MP),self)
        elif myrole==5:
            self.myinformation4=QLabel('行动力：'+str(role5().MP),self)
        elif myrole==6:
            self.myinformation4=QLabel('行动力：'+str(role6().MP),self)
        self.myinformation4.move(200,60)
        self.myinformation4.resize(80,30)
        self.myinformation4.setStyleSheet('border: 2px solid blue;background-color: white')
        self.myinformation4.setScaledContents(True)
        self.myinformation4.show()

        self.myinformation5=QLabel('护甲:0',self)
        self.myinformation5.move(200,90)
        self.myinformation5.resize(80,30)
        self.myinformation5.setStyleSheet('border: 2px solid green;background-color: white')
        self.myinformation5.setScaledContents(True)
        self.myinformation5.show()

        self.myinformation6=QLabel('牌堆:30',self)
        self.myinformation6.move(200,120)
        self.myinformation6.resize(80,30)
        self.myinformation6.setStyleSheet('border: 2px solid orange;background-color: white')
        self.myinformation6.setScaledContents(True)
        self.myinformation6.show()
        #电脑信息展示
        self.itsinformation=QLabel(self)
        global itsrole
        if itsrole==1:
            self.itsinformation.setPixmap(QPixmap('role1.jpg')) 
        elif itsrole==2:
            self.itsinformation.setPixmap(QPixmap('role2.jpg'))
        elif itsrole==3:
            self.itsinformation.setPixmap(QPixmap('role3.jpg'))
        elif itsrole==4:
            self.itsinformation.setPixmap(QPixmap('role4.jpg'))
        elif itsrole==5:
            self.itsinformation.setPixmap(QPixmap('role5.jpg'))
        elif itsrole==6:
            self.itsinformation.setPixmap(QPixmap('role6.jpg'))
        self.itsinformation.move(1240,650)
        self.itsinformation.resize(200,200)
        self.itsinformation.setStyleSheet('border: 2px solid black;')
        self.itsinformation.setScaledContents(True)
        self.itsinformation.show()

        if itsrole==1:
            self.itsinformation2=QLabel(role1().name+'(电脑)',self)
        elif itsrole==2:
            self.itsinformation2=QLabel(role2().name+'(电脑)',self)
        elif itsrole==3:
            self.itsinformation2=QLabel(role3().name+'(电脑)',self)
        elif itsrole==4:
            self.itsinformation2=QLabel(role4().name+'(电脑)',self)
        elif itsrole==5:
            self.itsinformation2=QLabel(role5().name+'(电脑)',self)
        elif itsrole==6:
            self.itsinformation2=QLabel(role6().name+'(电脑)',self)
        self.itsinformation2.move(1160,650)
        self.itsinformation2.resize(80,30)
        self.itsinformation2.setStyleSheet('border: 2px solid black;background-color: white')
        self.itsinformation2.setScaledContents(True)
        self.itsinformation2.show()

        if itsrole==1:
            self.itsinformation3=QLabel('生命：'+str(role1().HP),self)
        elif itsrole==2:
            self.itsinformation3=QLabel('生命：'+str(role2().HP),self)
        elif itsrole==3:
            self.itsinformation3=QLabel('生命：'+str(role3().HP),self)
        elif itsrole==4:
            self.itsinformation3=QLabel('生命：'+str(role4().HP),self)
        elif itsrole==5:
            self.itsinformation3=QLabel('生命：'+str(role5().HP),self)
        elif itsrole==6:
            self.itsinformation3=QLabel('生命：'+str(role6().HP),self)
        self.itsinformation3.move(1160,680)
        self.itsinformation3.resize(80,30)
        self.itsinformation3.setStyleSheet('border: 2px solid red;background-color: white')
        self.itsinformation3.setScaledContents(True)
        self.itsinformation3.show()

        if itsrole==1:
            self.itsinformation4=QLabel('行动力：'+str(role1().MP),self)
        elif itsrole==2:
            self.itsinformation4=QLabel('行动力：'+str(role2().MP),self)
        elif itsrole==3:
            self.itsinformation4=QLabel('行动力：'+str(role3().MP),self)
        elif itsrole==4:
            self.itsinformation4=QLabel('行动力：'+str(role4().MP),self)
        elif itsrole==5:
            self.itsinformation4=QLabel('行动力：'+str(role5().MP),self)
        elif itsrole==6:
            self.itsinformation4=QLabel('行动力：'+str(role6().MP),self)
        self.itsinformation4.move(1160,710)
        self.itsinformation4.resize(80,30)
        self.itsinformation4.setStyleSheet('border: 2px solid blue;background-color: white')
        self.itsinformation4.setScaledContents(True)
        self.itsinformation4.show()

        self.itsinformation5=QLabel('护甲:0',self)
        self.itsinformation5.move(1160,740)
        self.itsinformation5.resize(80,30)
        self.itsinformation5.setStyleSheet('border: 2px solid green;background-color: white')
        self.itsinformation5.setScaledContents(True)
        self.itsinformation5.show()

        self.itsinformation6=QLabel('牌堆:30',self)
        self.itsinformation6.move(1160,770)
        self.itsinformation6.resize(80,30)
        self.itsinformation6.setStyleSheet('border: 2px solid orange;background-color: white')
        self.itsinformation6.setScaledContents(True)
        self.itsinformation6.show()
        
        #初始化玩家牌库
        self.myleftcards=[]
        if myrole==1:
            for i in range(40):
                s=randint(0,4)
                self.myleftcards+=[role1().cards[s]]
        elif myrole==2:
            for i in range(40):
                s=randint(0,4)
                self.myleftcards+=[role2().cards[s]]
        elif myrole==3:
            for i in range(40):
                s=randint(0,4)
                self.myleftcards+=[role3().cards[s]]
        elif myrole==4:
            for i in range(40):
                s=randint(0,4)
                self.myleftcards+=[role4().cards[s]]
        elif myrole==5:
            for i in range(40):
                s=randint(0,4)
                self.myleftcards+=[role5().cards[s]]
        elif myrole==6:
            for i in range(40):
                s=randint(0,4)
                self.myleftcards+=[role6().cards[s]]
        
        #初始化电脑牌库
        self.itsleftcards=[]
        if itsrole==1:
            for j in range(40):
                s=randint(0,4)
                self.itsleftcards+=[role1().cards[s]]
        elif itsrole==2:
            for j in range(40):
                s=randint(0,4)
                self.itsleftcards+=[role2().cards[s]]
        elif itsrole==3:
            for j in range(40):
                s=randint(0,4)
                self.itsleftcards+=[role3().cards[s]]
        elif itsrole==4:
            for j in range(40):
                s=randint(0,4)
                self.itsleftcards+=[role4().cards[s]]
        elif itsrole==5:
            for j in range(40):
                s=randint(0,4)
                self.itsleftcards+=[role5().cards[s]]
        elif itsrole==6:
            for j in range(40):
                s=randint(0,4)
                self.itsleftcards+=[role6().cards[s]]
        
        #初始化双方手牌
        self.myhandcards=[]
        self.itshandcards=[]
        for t in range(5):
            self.getcard(self.myleftcards,self.myhandcards)
            self.getcard(self.itsleftcards,self.itshandcards)
        
        #回合内设置
        global roundnow
        self.roundtip=QLabel('游戏开始',self)
        roundnow=randint(0,1)
        self.roundlist=['你的回合','敌方回合']
        self.roundtip.setText(self.roundlist[roundnow])
        self.roundtip.resize(200,100)
        self.roundtip.move(620,0)
        self.roundtipfont=QFont()
        self.roundtipfont.setPointSize(33)
        self.roundtipfont.setWeight(40)
        self.roundtip.setFont(self.roundtipfont)
        self.roundtip.setStyleSheet('border: 2px solid white;background-color: white')
        self.roundtip.show()
        self.roundend=QPushButton('结束回合',self)
        self.roundend.resize(200,100)
        self.roundend.move(620,400)
        self.roundend.setFont(self.roundtipfont)
        self.roundend.setStyleSheet('border: 2px solid black;background-color: white')
        self.roundend.clicked.connect(self.roundtransform)
        self.tip=QLabel('当前行动',self)
        self.tip.resize(200,200)
        self.tip.move(620,600)
        self.tip.setStyleSheet('border: 2px solid white;background-color: white')
        tipfont=QFont()
        tipfont.setPointSize(15)
        self.tip.setFont(tipfont)
        self.tip.setWordWrap(True)
        self.tip.show()
        
        #初始化人物属性
        global hp1
        global lp1
        global mp1
        global hp2
        global mp2
        global lp2
        if myrole==1:
            hp1=role1().HP
            mp1=role1().MP
            lp1=0
        elif myrole==2:
            hp1=role2().HP
            mp1=role2().MP
            lp1=0
        elif myrole==3:
            hp1=role3().HP
            mp1=role3().MP
            lp1=0
        elif myrole==4:
            hp1=role4().HP
            mp1=role4().MP
            lp1=0
        elif myrole==5:
            hp1=role5().HP
            mp1=role5().MP
            lp1=0
        elif myrole==6:
            hp1=role6().HP
            mp1=role6().MP
            lp1=0
        if itsrole==1:
            hp2=role1().HP
            mp2=role1().MP
            lp2=0
        elif itsrole==2:
            hp2=role2().HP
            mp2=role2().MP
            lp2=0
        elif itsrole==3:
            hp2=role3().HP
            mp2=role3().MP
            lp2=0      
        elif itsrole==4:
            hp2=role4().HP
            mp2=role4().MP
            lp2=0 
        elif itsrole==5:
            hp2=role5().HP
            mp2=role5().MP
            lp2=0  
        elif itsrole==6:
            hp2=role6().HP
            mp2=role6().MP
            lp2=0       
        #初始化刷新界面
        self.mygroup=QButtonGroup(self)
        self.itsgroup=QButtonGroup(self)
        self.mydic={}
        self.itsdic={}
        self.firstround()
        self.refresh()
        
        
        
        #每帧刷新
    def refresh(self):
        global hp1
        global lp1
        global mp1
        global hp2
        global mp2
        global lp2
        global roundnow
        for e in self.mygroup.buttons():
            e.close()
        for e in self.itsgroup.buttons():
            e.close()
        self.mygroup=QButtonGroup(self)
        self.itsgroup=QButtonGroup(self)
        self.myinformation3.setText('生命：'+str(hp1))
        self.myinformation4.setText('行动力：'+str(mp1))
        self.myinformation5.setText('护甲：'+str(lp1))
        self.myinformation6.setText('牌堆：'+str(len(self.myleftcards)))
        self.itsinformation3.setText('生命：'+str(hp2))
        self.itsinformation4.setText('行动力：'+str(mp2))
        self.itsinformation5.setText('护甲：'+str(lp2))
        self.itsinformation6.setText('牌堆：'+str(len(self.itsleftcards)))       
        if self.myhandcards:
            height1=650//len(self.myhandcards)
        btofont=QFont()
        for c in range(len(self.myhandcards)):
            bto=QRadioButton(self.myhandcards[c].name,self)
            self.mygroup.addButton(bto)
            self.mydic[bto]=self.myhandcards[c]
            bto.resize(200,height1)
            btofont.setPointSize(min(height1//4,30))
            bto.setFont(btofont)
            bto.move(0,c*height1+200)
            if self.myhandcards[c].mp==0:
                bto.setStyleSheet('border: 2px solid white;background-color: white')
            elif self.myhandcards[c].mp==1:
                bto.setStyleSheet('border: 2px solid pink;background-color: pink')
            elif self.myhandcards[c].mp==2:
                bto.setStyleSheet('border: 2px solid purple;background-color: purple')
            bto.clicked.connect(lambda :self.play(self.myhandcards,self.myleftcards,self.itshandcards,self.itsleftcards,self.mydic[self.mygroup.checkedButton()],hp1,mp1,lp1,hp2,mp2,lp2))
            bto.show()            
            
        if self.itshandcards:
            height2=650//len(self.itshandcards)
        btofont2=QFont()
        for c in range(len(self.itshandcards)):
            bto=QRadioButton(self.itshandcards[c].name,self)
            self.itsgroup.addButton(bto)
            self.itsdic[bto]=self.itshandcards[c]
            bto.resize(200,height2)
            btofont2.setPointSize(min(height2//4,30))
            bto.setFont(btofont)
            bto.move(1240,c*height2)
            if self.itshandcards[c].mp==0:
                bto.setStyleSheet('border: 2px solid white;background-color: white')
            elif self.itshandcards[c].mp==1:
                bto.setStyleSheet('border: 2px solid pink;background-color: pink')
            elif self.itshandcards[c].mp==2:
                bto.setStyleSheet('border: 2px solid purple;background-color: purple')
            bto.clicked.connect(lambda :self.play(self.itshandcards,self.itsleftcards,self.myhandcards,self.myleftcards,self.itsdic[self.itsgroup.checkedButton()],hp2,mp2,lp2,hp1,mp1,lp1))
            bto.show()           
            
        for bt in self.itsgroup.buttons():
            bt.setEnabled(False)
        if roundnow==1:
            for bt in self.mygroup.buttons():
                bt.setEnabled(False)
            self.roundend.setEnabled(False)
            self.roundtip.setText('敌方回合')
        elif roundnow==0:
            for bt in self.mygroup.buttons():
                bt.setEnabled(True)
            self.roundend.setEnabled(True)
            self.roundtip.setText('你的回合')
        self.checkwin()
        
        #电脑出牌逻辑
    def aiplay(self):
        global hp1
        global mp1
        global lp1
        global hp2
        global mp2
        global lp2
        thisround=True
        while thisround:
            if not self.itshandcards:
                break
            for ll in self.itshandcards:
                QApplication.processEvents()
                if ll.mp==0:
                    sleep(3)
                    self.play(self.itshandcards,self.itsleftcards,self.myhandcards,self.myleftcards,ll,hp2,mp2,lp2,hp1,mp1,lp1)
                    thisround=True
                    break
                else:
                    thisround=False
            if not self.itshandcards:
                break
            for ls in self.itshandcards:
                QApplication.processEvents()
                if ls.mp<=mp2:
                    sleep(3)
                    self.play(self.itshandcards,self.itsleftcards,self.myhandcards,self.myleftcards,ls,hp2,mp2,lp2,hp1,mp1,lp1)
                    thisround=True
                    break
                else:
                    thisround=False
        QApplication.processEvents()
        sleep(1.5)
        self.roundtransform()

    #首回合判定及额外护甲
    def firstround(self):
        global roundnow
        global lp1
        global lp2
        if roundnow==0:
            lp2+=5
        elif roundnow==1:
            lp1+=5
            QTimer.singleShot(2000,self.aiplay)
            

    #回合交替
    def roundtransform(self):
        global roundnow
        global mp1
        global lp1
        global mp2
        global lp2
        if roundnow==0:
            roundnow=1
            self.getcard(self.itsleftcards,self.itshandcards)
            self.getcard(self.itsleftcards,self.itshandcards)
            if itsrole==1:
                mp2=role1().MP
                lp2=0
            elif itsrole==2:
                mp2=role2().MP
                lp2=0
            elif itsrole==3:
                mp2=role3().MP
                lp2=0
            elif itsrole==4:
                mp2=role4().MP
                lp2=0
            elif itsrole==5:
                mp2=role5().MP
                lp2=0
            elif itsrole==6:
                mp2=role6().MP
                lp2=0
            self.refresh()
            QTimer.singleShot(2000,self.aiplay)
                     
        elif roundnow==1:
            roundnow=0
            self.getcard(self.myleftcards,self.myhandcards)
            self.getcard(self.myleftcards,self.myhandcards)
            if myrole==1:
                mp1=role1().MP
                lp1=0
            elif myrole==2:
                mp1=role2().MP
                lp1=0
            elif myrole==3:
                mp1=role3().MP
                lp1=0
            elif myrole==4:
                mp1=role4().MP
                lp1=0
            elif myrole==5:
                mp1=role5().MP
                lp1=0
            elif myrole==6:
                mp1=role6().MP
                lp1=0
            self.refresh()
            


    #检查游戏是否结束
    def checkwin(self):
        global hp1
        global hp2
        if hp1<=0 or not self.myleftcards:
            self.close()
            self.ui=itwin()
            self.ui.show()
        elif hp2<=0 or not self.itsleftcards:
            self.close()
            self.ui=iwin()
            self.ui.show()

    #出牌加上刷新
    def play(self,myhandcards,myleftcards,itshandcards,itsleftcards,card,HP1,MP1,LP1,HP2,MP2,LP2):
        global hp1
        global lp1
        global mp1
        global hp2
        global mp2
        global lp2
        global roundnow
        global myrole
        global itsrole
        endding=self.palycard(myhandcards,myleftcards,itshandcards,itsleftcards,card,HP1,MP1,LP1,HP2,MP2,LP2)
        if roundnow==0 and endding:
            hp1,mp1,lp1,hp2,mp2,lp2=endding
            if myrole==1:
                self.tip.setText(role1().name+'（你）打出了'+'《'+card.name+'》,效果为：'+card.able)
            elif myrole==2:
                self.tip.setText(role2().name+'（你）打出了'+'《'+card.name+'》,效果为：'+card.able)
            elif myrole==3:
                self.tip.setText(role3().name+'（你）打出了'+'《'+card.name+'》,效果为：'+card.able)
            elif myrole==4:
                self.tip.setText(role4().name+'（你）打出了'+'《'+card.name+'》,效果为：'+card.able)
            elif myrole==5:
                self.tip.setText(role5().name+'（你）打出了'+'《'+card.name+'》,效果为：'+card.able)
            elif myrole==6:
                self.tip.setText(role6().name+'（你）打出了'+'《'+card.name+'》,效果为：'+card.able)
        elif roundnow==1 and endding:
            hp2,mp2,lp2,hp1,mp1,lp1=endding
            if itsrole==1:
                self.tip.setText(role1().name+'（电脑）打出了'+'《'+card.name+'》,效果为：'+card.able)
            elif itsrole==2:
                self.tip.setText(role2().name+'（电脑）打出了'+'《'+card.name+'》,效果为：'+card.able)
            elif itsrole==3:
                self.tip.setText(role3().name+'（电脑）打出了'+'《'+card.name+'》,效果为：'+card.able)
            elif itsrole==4:
                self.tip.setText(role4().name+'（电脑）打出了'+'《'+card.name+'》,效果为：'+card.able)
            elif itsrole==5:
                self.tip.setText(role5().name+'（电脑）打出了'+'《'+card.name+'》,效果为：'+card.able)
            elif itsrole==6:
                self.tip.setText(role6().name+'（电脑）打出了'+'《'+card.name+'》,效果为：'+card.able)
        self.refresh()
        return

    #出牌函数
    def palycard(self,myhandcards,myleftcards,itshandcards,itsleftcards,card,HP1,MP1,LP1,HP2,MP2,LP2):
        if card.mp>MP1:
            return ()
        return card.ability(myhandcards,myleftcards,itshandcards,itsleftcards,HP1,MP1,LP1,HP2,MP2,LP2)
    
    #抽牌函数
    def getcard(self,leftcards,handcards):
        if not(leftcards):
            return
        handcards.append(leftcards.pop())
        return
                  
    def paintEvent(self,event):
        painter = QPainter(self)
        pixmap = QPixmap("battle background.jpg")
        painter.drawPixmap(self.rect(), pixmap)



#人机对战选人界面2
class playWithAIUI2(QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("青城决")
        self.resize(1440, 850)
        self.setWindowIcon(QIcon('menu a.jpg'))
        
        tip=QLabel('请选择电脑的侠客',self)
        tip.move(550,40)
        tip.resize(500,250)
        fonttip= QFont()
        fonttip.setPointSize(40)
        fonttip.setWeight(50)
        tip.setFont(fonttip)
        tip.show()

        self.role1tick=QPushButton(role1().name,self)
        self.role1tick.move(270,300)
        self.role1tick.resize(400,100)
        fontrole1= QFont()
        fontrole1.setPointSize(40)
        fontrole1.setWeight(50)
        self.role1tick.setFont(fontrole1)
        self.role1tick.show()
        self.role1tick.clicked.connect(self.role1)

        self.role2tick=QPushButton(role2().name,self)
        self.role2tick.move(270,500)
        self.role2tick.resize(400,100)
        fontrole2= QFont()
        fontrole2.setPointSize(40)
        fontrole2.setWeight(50)
        self.role2tick.setFont(fontrole2)
        self.role2tick.show()
        self.role2tick.clicked.connect(self.role2)

        self.role3tick=QPushButton(role3().name,self)
        self.role3tick.move(270,700)
        self.role3tick.resize(400,100)
        fontrole3= QFont()
        fontrole3.setPointSize(40)
        fontrole3.setWeight(50)
        self.role3tick.setFont(fontrole3)
        self.role3tick.show()
        self.role3tick.clicked.connect(self.role3)

        self.role4tick=QPushButton(role4().name,self)
        self.role4tick.move(820,300)
        self.role4tick.resize(400,100)
        fontrole4= QFont()
        fontrole4.setPointSize(40)
        fontrole4.setWeight(50)
        self.role4tick.setFont(fontrole4)
        self.role4tick.show()
        self.role4tick.clicked.connect(self.role4)

        self.role5tick=QPushButton(role5().name,self)
        self.role5tick.move(820,500)
        self.role5tick.resize(400,100)
        fontrole5= QFont()
        fontrole5.setPointSize(40)
        fontrole5.setWeight(50)
        self.role5tick.setFont(fontrole5)
        self.role5tick.show()
        self.role5tick.clicked.connect(self.role5)

        self.role6tick=QPushButton(role6().name,self)
        self.role6tick.move(820,700)
        self.role6tick.resize(400,100)
        fontrole6= QFont()
        fontrole6.setPointSize(40)
        fontrole6.setWeight(50)
        self.role6tick.setFont(fontrole6)
        self.role6tick.show()
        self.role6tick.clicked.connect(self.role6)

    def role1(self):
        self.close()
        global itsrole
        itsrole=1
        self.ui1=playWithAI()
        self.ui1.show()

    def role2(self):
        self.close()
        global itsrole
        itsrole=2
        self.ui2=playWithAI()
        self.ui2.show()

    def role3(self):
        self.close()
        global itsrole
        itsrole=3
        self.ui3=playWithAI()
        self.ui3.show()

    def role4(self):
        self.close()
        global itsrole
        itsrole=4
        self.ui3=playWithAI()
        self.ui3.show()

    def role5(self):
        self.close()
        global itsrole
        itsrole=5
        self.ui3=playWithAI()
        self.ui3.show()

    def role6(self):
        self.close()
        global itsrole
        itsrole=6
        self.ui3=playWithAI()
        self.ui3.show()

    def paintEvent(self,event):
        painter = QPainter(self)
        pixmap = QPixmap("battle background.jpg")
        painter.drawPixmap(self.rect(), pixmap)



#人机对战选人界面1
class playWithAIUI(QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("青城决")
        self.resize(1440, 850)
        self.setWindowIcon(QIcon('menu a.jpg'))
        
        tip=QLabel('请选择你的侠客',self)
        tip.move(550,40)
        tip.resize(500,250)
        fonttip= QFont()
        fonttip.setPointSize(40)
        fonttip.setWeight(50)
        tip.setFont(fonttip)
        tip.show()

        self.role1tick=QPushButton(role1().name,self)
        self.role1tick.move(270,300)
        self.role1tick.resize(400,100)
        fontrole1= QFont()
        fontrole1.setPointSize(40)
        fontrole1.setWeight(50)
        self.role1tick.setFont(fontrole1)
        self.role1tick.show()
        self.role1tick.clicked.connect(self.role1)

        self.role2tick=QPushButton(role2().name,self)
        self.role2tick.move(270,500)
        self.role2tick.resize(400,100)
        fontrole2= QFont()
        fontrole2.setPointSize(40)
        fontrole2.setWeight(50)
        self.role2tick.setFont(fontrole2)
        self.role2tick.show()
        self.role2tick.clicked.connect(self.role2)

        self.role3tick=QPushButton(role3().name,self)
        self.role3tick.move(270,700)
        self.role3tick.resize(400,100)
        fontrole3= QFont()
        fontrole3.setPointSize(40)
        fontrole3.setWeight(50)
        self.role3tick.setFont(fontrole3)
        self.role3tick.show()
        self.role3tick.clicked.connect(self.role3)

        self.role4tick=QPushButton(role4().name,self)
        self.role4tick.move(820,300)
        self.role4tick.resize(400,100)
        fontrole4= QFont()
        fontrole4.setPointSize(40)
        fontrole4.setWeight(50)
        self.role4tick.setFont(fontrole4)
        self.role4tick.show()
        self.role4tick.clicked.connect(self.role4)

        self.role5tick=QPushButton(role5().name,self)
        self.role5tick.move(820,500)
        self.role5tick.resize(400,100)
        fontrole5= QFont()
        fontrole5.setPointSize(40)
        fontrole5.setWeight(50)
        self.role5tick.setFont(fontrole5)
        self.role5tick.show()
        self.role5tick.clicked.connect(self.role5)

        self.role6tick=QPushButton(role6().name,self)
        self.role6tick.move(820,700)
        self.role6tick.resize(400,100)
        fontrole6= QFont()
        fontrole6.setPointSize(40)
        fontrole6.setWeight(50)
        self.role6tick.setFont(fontrole6)
        self.role6tick.show()
        self.role6tick.clicked.connect(self.role6)

    def role1(self):
        self.close()
        global myrole
        myrole=1
        self.ui1=playWithAIUI2()
        self.ui1.show()

    def role2(self):
        self.close()
        global myrole
        myrole=2
        self.ui2=playWithAIUI2()
        self.ui2.show()

    def role3(self):
        self.close()
        global myrole
        myrole=3
        self.ui3=playWithAIUI2()
        self.ui3.show()

    def role4(self):
        self.close()
        global myrole
        myrole=4
        self.ui3=playWithAIUI2()
        self.ui3.show()

    def role5(self):
        self.close()
        global myrole
        myrole=5
        self.ui3=playWithAIUI2()
        self.ui3.show()

    def role6(self):
        self.close()
        global myrole
        myrole=6
        self.ui3=playWithAIUI2()
        self.ui3.show()

    def paintEvent(self,event):
        painter = QPainter(self)
        pixmap = QPixmap("battle background.jpg")
        painter.drawPixmap(self.rect(), pixmap)



#联机模式身份选择界面
class playOnlineUI(QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("青城决")
        self.resize(1440, 850)
        self.setWindowIcon(QIcon('menu a.jpg'))

        tip=QLabel('请选择你的身份',self)
        tip.move(550,40)
        tip.resize(500,250)
        font = QFont()
        font.setPointSize(40)
        font.setWeight(50)
        tip.setFont(font)
        tip.show()

        self.sever=QPushButton('房主',self)
        self.sever.move(520,500)
        self.sever.resize(400,100)
        
        self.sever.setFont(font)
        self.sever.show()
        self.sever.clicked.connect(self.severui)

        self.client=QPushButton('游客',self)
        self.client.move(520,300)
        self.client.resize(400,100)
        self.client.setFont(font)
        self.client.show()
        self.client.clicked.connect(self.clientui)

    def severui(self):
        self.close()
        self.ui=severfirstui()
        self.ui.show()

    def clientui(self):
        self.close()
        self.ui=clientfirstui()
        self.ui.show()
    
    def paintEvent(self,event):
        painter = QPainter(self)
        pixmap = QPixmap("battle background.jpg")
        painter.drawPixmap(self.rect(), pixmap)



#开始界面
class gamestart(QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("青城决")
        self.resize(1440, 850)
        self.setWindowIcon(QIcon('menu a.jpg'))

        tip=QLabel('青城决',self)
        tip.move(550,0)
        tip.resize(500,250)
        font0=QFont()
        font0.setPointSize(80)
        font0.setWeight(50)
        tip.setFont(font0)
        tip.show()
        
        #人机对战
        self.ai_button=QPushButton('人机对战',self)
        self.ai_button.move(520,500)
        self.ai_button.resize(400,100)
        font = QFont()
        font.setPointSize(40)
        font.setWeight(50)
        self.ai_button.setFont(font)
        self.ai_button.show()
        self.ai_button.clicked.connect(self.playWithAI)
        #联机对战
        self.online_button=QPushButton('联机对战',self)
        self.online_button.move(520,300)
        self.online_button.resize(400,100)
        self.online_button.setFont(font)
        self.online_button.show()
        self.online_button.clicked.connect(self.playOnline)

    def playWithAI(self):
        self.close()
        self.gaming_ui=playWithAIUI()
        self.gaming_ui.show()

    def playOnline(self):
        self.close()
        self.gaming_ui=playOnlineUI()
        self.gaming_ui.show()


    def paintEvent(self,event):
        painter = QPainter(self)
        pixmap = QPixmap("menu background.jpg")
        # 绘制窗口背景，平铺到整个窗口，随着窗口改变而改变
        painter.drawPixmap(self.rect(), pixmap)
    


#启动开始界面
if __name__ == "__main__":
    import sys
    app =QApplication(sys.argv)
    ui=gamestart()
    ui.show()
    sys.exit(app.exec())




    

